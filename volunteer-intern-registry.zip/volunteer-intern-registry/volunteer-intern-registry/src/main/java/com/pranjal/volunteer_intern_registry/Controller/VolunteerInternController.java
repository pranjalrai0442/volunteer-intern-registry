package com.pranjal.volunteer_intern_registry.Controller;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.oauth2.core.user.OAuth2User;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.pranjal.volunteer_intern_registry.model.InternInfo;
import com.pranjal.volunteer_intern_registry.service.VolunteerService;

@RestController
public class VolunteerInternController {
	
	@Autowired
	VolunteerService serv1;
	

	@PostMapping("/register")
	public ResponseEntity<?> register(@RequestBody InternInfo intern) {
		if (intern.getEmail() == null) {
	        return ResponseEntity.badRequest().body("Email is required");
	    }
		InternInfo i1 = serv1.registerintern(intern);
		 
		 return (ResponseEntity.ok("Intern Registered"));
		
	}
	@GetMapping("/viewlist")
    public List<InternInfo> view(@AuthenticationPrincipal OAuth2User user) {
        String email = user.getAttribute("email");
        System.out.println("Logged-in admin:" + email);
        return serv1.viewlist();
    }
	
	
}
