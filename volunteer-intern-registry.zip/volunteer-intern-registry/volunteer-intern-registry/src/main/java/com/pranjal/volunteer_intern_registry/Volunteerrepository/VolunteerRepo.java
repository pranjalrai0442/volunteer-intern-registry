package com.pranjal.volunteer_intern_registry.Volunteerrepository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.pranjal.volunteer_intern_registry.model.InternInfo;

public interface VolunteerRepo extends JpaRepository<InternInfo, String> {

}
