package com.pranjal.volunteer_intern_registry;

import java.util.List;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.authorization.AuthorizationDecision;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.oauth2.core.user.OAuth2User;
import org.springframework.security.web.SecurityFilterChain;

@Configuration
@EnableWebSecurity
public class VolunteerConfig {

    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
        http
            .csrf(csrf -> csrf.disable())
            .authorizeHttpRequests(auth -> auth
                .requestMatchers("/register").permitAll() // No auth for this
                .requestMatchers("/viewlist").access((authentication, context) -> {
                    var principal = authentication.get().getPrincipal();
                    if (principal instanceof OAuth2User user) {
                        String email = user.getAttribute("email");
                        return new AuthorizationDecision(
                            email != null &&
                            List.of("admin@example.com", "reviewer@gmail.com").contains(email.toLowerCase())
                        );
                    }
                    return new AuthorizationDecision(false);
                })
                .anyRequest().denyAll()
            )
            .oauth2Login(oauth -> oauth
                .defaultSuccessUrl("/viewlist", true)
            );

        return http.build();
    }
}
