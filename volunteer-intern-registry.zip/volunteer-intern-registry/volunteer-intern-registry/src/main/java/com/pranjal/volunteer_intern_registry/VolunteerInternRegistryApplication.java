package com.pranjal.volunteer_intern_registry;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class VolunteerInternRegistryApplication {

	public static void main(String[] args) {
		SpringApplication.run(VolunteerInternRegistryApplication.class, args);
		System.out.print("Hello");
	}

}
