package com.pranjal.volunteer_intern_registry.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.pranjal.volunteer_intern_registry.Volunteerrepository.VolunteerRepo;
import com.pranjal.volunteer_intern_registry.model.InternInfo;

@Service
public class VolunteerService {

	@Autowired
	VolunteerRepo repo;
	
	public InternInfo registerintern(InternInfo intern) {
		 
		repo.save(intern);
		return intern;
		
	}

	public List<InternInfo> viewlist() {
		return repo.findAll();
	}

}
